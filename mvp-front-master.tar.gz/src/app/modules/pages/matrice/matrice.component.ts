import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import * as MatriceActions from '../../cors/ngrx/actions/matrice.action';
@Component({
  selector: 'app-matrice',
  templateUrl: './matrice.component.html',
  styleUrls: ['./matrice.component.css']
})
export class MatriceComponent implements OnInit {
  matrice;
  id;
  log=console.log
  constructor(private store:Store<any>,private activatedRoute:ActivatedRoute) { 
    this.matrice = store.select('matrice')
  
    this.id = atob(this.activatedRoute.snapshot.paramMap.get('id'));
  }
  
  ngOnInit() {
    this.store.dispatch({ type: MatriceActions.GET_BYID_MATRICE, payload: {  id:"288ea36c-784a-4a8c-926a-c08c82fc1abf",
      body:{

        description: "hello in matrice",
        nom: "matrie "+Date.now(),
        type: "matrice"
      }
    }})
  }
  ajouterAxe(){
    this.store.dispatch({ type: MatriceActions.ADD_AXE})
  }
}
