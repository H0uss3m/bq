import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { ActivatedRoute } from '@angular/router';
import * as ModeleActions from '../../cors/ngrx/actions/modele.actions';

@Component({
  selector: 'app-modeles',
  templateUrl: './modeles.component.html',
  styleUrls: ['./modeles.component.css']
})
export class ModelesComponent implements OnInit {

  log = console.log;
  modele;
  id;
  constructor(private store: Store<any>, private activatedRoute: ActivatedRoute) {
    this.modele = store.select('modele')
  }

  ngOnInit() {

  }
  ajouterAxe(){
    this.store.dispatch({ type: ModeleActions.ADD_AXE})
  }
  deleteModele = () => {

  }
}
