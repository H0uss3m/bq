import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class ModeleService {
  
  endPoint =  environment.endPoint37;
  constructor(private httpClient:HttpClient,private router:Router) { }
  getByIdModeleById(data){
    console.log('data',data)
    return this.httpClient.post(this.endPoint + '/api/v1/modeles ',data)
  }
  navigateToModeleById(id){
    return this.router.navigateByUrl('/modeles/id/'+btoa(id))
  }
}
