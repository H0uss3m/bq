export const environment = {
  production: true,
  endPoint: 'http://37.187.146.184:2020'
};
